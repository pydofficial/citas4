# BookMedik
Sistema de Citas Medicas usando PHP, MySQL y Bootstrap.

Link: http://evilnapsis.com/2015/08/10/bookmedik-sistema-de-citas-medicas/

### Version 2.0

- Gestion de Pacientes, Medicos
- Creacion de Citas: Asunto, Paciente, medico, Fecha, Hora, Enfermedad, Sintomas, Medicamentos, Costo
- Vista de Calendario
- Correccion de Bugs
- Integracion de Areas con Medicos
- Integracion de estado de cita y tipo de pago
- Busqueda avanzada
- Reportes por paciente, medico, rango de fecha, estado, tipo de pago
- Descarga de reporte enformato word

### Powered by Evilnapsis