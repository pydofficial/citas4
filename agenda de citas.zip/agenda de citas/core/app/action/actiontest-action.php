<?php

 print_r($params);

?>